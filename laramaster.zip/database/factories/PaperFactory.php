<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Paper;
use Faker\Generator as Faker;

$factory->define(Paper::class, function (Faker $faker) {
    return [
        'name'=>$faker->word,
    ];
});
