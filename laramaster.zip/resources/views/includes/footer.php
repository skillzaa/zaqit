<br>
<br>
<footer class="page-footer font-small bg-secondary">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href=""> Zaqit.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
