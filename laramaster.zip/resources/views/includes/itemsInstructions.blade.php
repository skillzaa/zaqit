<footer class="footer border border-primary">
    <div class="container">
    <div class="text-muted">Place Do not use Names already used.Already used named will not be accepted.</div>
    <div class="text-muted">Please use Alphanumeric characters with spaces and dashes only</div>
    <div class="text-muted">Maximum 100 Characters long.</div>
    <div class="text-muted">Minimum 3 Characters long.</div>
    </div>
    </footer>
