<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  Manage
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
  <a class="dropdown-item" href="{{ url('/subject') }}">Subject</a>
  <a class="dropdown-item" href="{{ url('/level') }}">Level</a>
  <a class="dropdown-item" href="{{ url('/displayheading') }}">Display Heading</a>
  <div class="dropdown-divider"></div>

  <a class="dropdown-item" href="{{ url('/student') }}">Students</a>
  
  <div class="dropdown-divider"></div>
  <a class="dropdown-item" href="{{ url('/question') }}">Question</a>
  <a class="dropdown-item" href="{{ url('/paper') }}">Paper</a>
</div>
</li>
