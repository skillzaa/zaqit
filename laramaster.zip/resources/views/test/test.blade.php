{{dd(Auth::user()->role)}}
{{dd($data)}}
