<div class="jumbotron card card-image" style="background-image: url(https://mdbootstrap.com/img/Photos/Others/gradient1.jpg);">
    <div class="text-white text-center py-5 px-4">
      <div>
        <h1 class="card-title h1-responsive pt-3 mb-5 font-bold"><strong>Test Your Way To Success</strong></h1>
        <h3 class="mx-5 mb-5">ZAQ Technologies is a state of the art testing system specially designed for students who want to secure high marks in professional tests. We have a large database of questions and their solutions to guage your strength and weaknesses.</h3>
        <a class="btn btn-outline-white btn-md"><i class="fas fa-clone left"></i>Take a Gereral Knowledge Test</a>
      </div>
    </div>
  </div>
