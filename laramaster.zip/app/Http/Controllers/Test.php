<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Paper;

class Test extends Controller
{
   public function index(){

   }

   public function show($id){
    $data = Paper::findOrFail($id);
    return view('test.test')->with("data",$data);


   }
}//class
