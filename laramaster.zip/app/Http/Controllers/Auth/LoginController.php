<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
class LoginController extends Controller
{

    use AuthenticatesUsers;

    //protected $redirectTo = RouteServiceProvider::HOME;


    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function redirectTo(){
   // User role
   // $role = Auth::user()->role->name;
        return '/';
    // Check user role
    // switch ($role) {
    //     case 'Manager':
    //             return '/dashboard';
    //         break;
    //     case 'Employee':
    //             return '/projects';
    //         break;
    //     default:
    //             return '/login';
    //         break;
    // }
    }
}
