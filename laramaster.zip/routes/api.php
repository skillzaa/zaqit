<?php

//use Illuminate\Http\Request;
//================COROS Headers=================
// header('Access-Control-Allow-Origin:  *');
// header('Access-Control-Allow-Methods:  POST, GET, OPTIONS, PUT, DELETE');
// header('Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Origin, Authorization');

// Route::get('/test', function () {
//     try {
//         throw new Exception('foobar');
//       } catch (Exception $e) {
//       //  Debugbar::addException($e);
//       }
// //...................................
// $arr = ["a","b","c"];
// Debugbar::info($arr);
// Debugbar::error('Error!');
// Debugbar::warning('Watch out…');
// Debugbar::addMessage('Another message', 'mylabel');
// //...................................

// return "Debugbar";
// });

//======================JWT Routes==========
// Route::post('/register', 'AuthController@register');
// Route::post('/login', 'AuthController@login');
// Route::post('/logout', 'AuthController@logout');
// Route::post('/getUser', 'AuthController@getUser');
//===========================================

//==================SUBJECT Route===========
// Route::apiResource('/subjects','SubjectsController');
// Route::apiResource('/levels','LevelsController');
// Route::apiResource('/questions','QuestionController');
//===========================================
